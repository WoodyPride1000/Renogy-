# Renogy チャージコントローラー バッテリーロガー(Arduino Uno 版)設計書

- 対象: `renogy_logger` rev.G
- 文書版: 1.0(2026-11-15)
- 状態: 設計とホスト側検証まで完了。**実機での動作確認は未実施**(`docs/09_decisions_and_limits.md` の未解決事項を参照)

## 構成

```text
README.md                          この文書
docs/
  01_overview.md                   概要、前提、要求(FR / NFR)
  02_hardware.md                   ハードウェア構成、ピン、I2C アドレス、配線
  03_architecture.md               ソフトウェア構成、起動シーケンス、状態、ループ
  04_data_and_storage.md           レコード構造、リングバッファ、復元、ダンプ、CSV 仕様
  05_fault_handling.md             障害モード、故障 LED、エスカレーション、バスクリア
  06_resources.md                  Flash / SRAM / スタック(実測)、時間
  07_verification.md               検証方法と結果、変異テスト、欠陥の記録、未検証事項
  08_operations.md                 ビルド、初回確認、コマンド、LED、データ回収、解析
  09_decisions_and_limits.md       設計判断(ADR)、制約、未解決事項、ESP32 移行
src/renogy_logger/
  renogy_logger.ino                include のみ
  renogy_logger.h                  実装
  host_test/                       ホスト側の電源断注入テスト(g++ のみで動く)
    run.sh  harness.cpp  hostenv.h
```

## 読み方

1. 全体像: `01` → `03`。
2. 品質の根拠: `04`(コミット順序と復元)→ `05`(障害)→ `07`(検証)。
3. 実機に載せる前: `02`(配線の前提)→ `06`(スタックの実測)→ `08`(初回確認)→ `09`(未解決事項)。

## 実機の前に確認すること(要約)

- 24FC1025 の A1/A2 の結線が、`02` 章 §3.1 の前提どおりか。
- `STATUS` の `Stack free (min)` が 100 B 以上か(`06` 章 §3.3)。
- Renogy の接続(MAX3232 経由の RS232、スレーブ 1、9600 bps)。

## ホスト側テストの実行

```bash
cd src/renogy_logger/host_test
bash run.sh quick    # 約 30 秒
bash run.sh          # 全件、約 3 分
```

Mermaid の図は、GitHub や VS Code(Markdown Preview Mermaid Support)などで表示できる。
