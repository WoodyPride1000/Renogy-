# 03. ソフトウェア構成

## 1. ファイル構成

| ファイル | 内容 |
|---|---|
| `renogy_logger.ino` | ライブラリの `#include` と `#include "renogy_logger.h"` のみ。**関数を持たない** |
| `renogy_logger.h` | 全実装(定数、構造体、I2C、EEPROM、復元、ダンプ、コマンド、setup/loop) |

分割の理由: Arduino IDE は `.ino` 内の関数に自動でプロトタイプを生成し、スケッチ冒頭(型定義より前)に挿入する。自作型(`LogRecord`、`ReadStatus`)を引数・戻り値に持つ関数があると `does not name a type` になる。実装を `.h` に置くと、この自動生成の対象外になる(09 章 ADR-09)。

## 2. 機能ブロック

| ブロック | 主な関数 | 役割 |
|---|---|---|
| 故障表示 | `setFault`、`updateFaultLed` | 原因ごとのビット管理と、点滅回数による表示 |
| I2C 保全 | `i2cBusClear`、`probeEepromChips` | SDA 固着の解放、EEPROM 応答確認 |
| 物理アドレス | `mapAddress` | 物理アドレス → I2C アドレス + ワードアドレス |
| EEPROM 入出力 | `readRecordWithStatus`、`writeBytesToEEPROM` | 3値ステータスの読み出し、16 B 分割の書き込み |
| 記録 | `writeRecord`、`logToEEPROM`、`readRenogyData`、`readTempTenths` | 1 レコードの生成と、検証つきの書き込み |
| 状態復元 | `recoverStateFromEEPROM`、`saveStateToEEPROM`、`recoveryTick` | 起動時の count 復元、復旧待ち |
| ダンプ | `flushToSD`、`writeCsvRow`、`printFixed` | 未出力分の CSV 追記 |
| 入出力 | `checkSerialCommands`、`handleCommand`、`handleButton` | コマンドとボタン |
| 計測 | `paintStack`、`stackFreeMin` | スタック最小余裕の実測 |

## 3. 起動シーケンス

```mermaid
flowchart TD
  A["電源投入 / リセット"] --> E0["earlyInit: MCUSR を退避 / WDT 停止"]
  E0 --> B["paintStack: 未使用 RAM を 0xA5 で塗る"]
  B --> C["i2cBusClear: SCL 9 クロック + STOP"]
  C --> D["GPIO / Serial / Modbus 初期化"]
  D --> W["wdt_enable 8 秒"]
  W --> F["EEPROM 応答確認 0x50-0x55"]
  F --> G["RTC 初期化 / 電池切れ検出"]
  G --> H{"状態復元"}
  H -->|"成功"| I["VALID"]
  H -->|"走査が中断 かつ ヒントあり"| J["DEGRADED: count = ヒント + 64"]
  H -->|"ヒント無し かつ バス死"| K["WAITING: 記録停止"]
  K -->|"30 秒ごとに バスクリア + 再走査 / FORCE"| I
```

## 4. 動作状態

```mermaid
stateDiagram-v2
  [*] --> Boot
  Boot --> VALID: 復元成功
  Boot --> DEGRADED: 走査中断 かつ ヒントあり
  Boot --> WAITING: ヒント無し かつ バス死
  DEGRADED --> VALID: 最初の書き込み成功
  WAITING --> VALID: 再走査が成功
  WAITING --> DEGRADED: 再走査が中断 かつ ヒントあり / FORCE
```

| 状態 | 記録 | ダンプ | 表示 |
|---|---|---|---|
| VALID | する | できる | なし |
| DEGRADED | する(count はヒントより先へ飛んでいる) | できる | 故障 LED 4 回(最初の書き込み成功で消える) |
| WAITING | **しない** | 拒否する | 故障 LED 4 回 |

## 5. メインループ(1 サイクル)

```mermaid
sequenceDiagram
  participant L as loop
  participant R as Renogy
  participant E as EEPROM x3
  participant I as 内蔵EEPROM
  L->>R: Modbus 読み出し 0x100 から 12 レジスタ 最大3回
  R-->>L: レジスタ値 / 失敗ならセンチネル
  L->>E: 前半 16 B 書き込み + ACK ポーリング
  L->>E: 後半 16 B 書き込み + ACK ポーリング
  L->>E: 32 B 読み戻し + memcmp
  alt 一致
    L->>L: globalCount を +1
    opt globalCount が 16 の倍数
      L->>I: ヒント 12 B を保存
    end
  else 不一致 / バスエラー
    L->>E: バスエラーならバスクリアして再試行 最大3回
  end
  L->>L: 次の分まで待機 シリアル / ボタン / LED を 100 ms ごとに処理
```

### 待機ロジック(`waitForNextMinute`)

- 100 ms ごとに WDT をリセットし、シリアルコマンド、ボタン、故障 LED を処理する。
- `rtc.now().minute()` が変わったら次のサイクルへ。ただし、**サイクル開始から 30 秒未満では抜けない**(バス死で RTC の値が不定でも、暴走して高速に記録しないため)。
- 60 秒経過で強制的に抜ける。
- 約 60 サイクル(1 時間)ごとに、EEPROM の応答確認を再実行して、故障 `F_IC` を更新する。

## 6. ブロッキングと WDT の対応

| 処理 | 最悪の所要時間 | WDT 対策 |
|---|---|---|
| Modbus 読み出し(失敗時 3 回) | 約 6 秒(応答待ち 2 秒 × 3) | 試行ごとに `wdt_reset` |
| EEPROM 書き込み(3 試行) | 数十〜数百 ms | 試行ごと / ACK ポーリング中に `wdt_reset` |
| 起動時の全数走査 | 約 10 秒(計算値) | 256 件ごとに `wdt_reset` |
| ダンプ(SD) | 数十秒以上(未測定) | 64 件ごとに `wdt_reset`。ただし `sd.begin()` などライブラリ内部は対策できない |

> 注意: 不良カードで `sd.begin()` が 8 秒を超えると、WDT リセットが FAT 更新の途中で起きうる(09 章 §3)。
