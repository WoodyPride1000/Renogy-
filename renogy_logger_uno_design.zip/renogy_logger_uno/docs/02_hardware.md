# 02. ハードウェア構成

## 1. ブロック図

```mermaid
flowchart LR
  subgraph Renogy
    RC["チャージコントローラー<br/>RS232 / Modbus RTU"]
  end
  RC -->|"RS232"| LS["MAX3232<br/>レベル変換"]
  LS -->|"D2 RX / D3 TX<br/>SoftwareSerial 9600"| UNO
  subgraph UNO["Arduino Uno ATmega328P"]
    CPU["ロジック"]
  end
  UNO <-->|"I2C A4 SDA / A5 SCL 400 kHz"| E["24FC1025 x3<br/>0x50-0x55"]
  UNO <-->|"I2C"| RTC["DS3231<br/>0x68"]
  UNO -->|"SPI D10 CS / D11 / D12 / D13"| SD["SD カード"]
  BTN["ボタン D4"] --> UNO
  UNO --> L1["状態 LED D13"]
  UNO --> L2["故障 LED A0"]
```

## 2. ピン割り当て

| ピン | 機能 | 備考 |
|---|---|---|
| D2 | Renogy RX(SoftwareSerial) | MAX3232 の出力側に接続 |
| D3 | Renogy TX(SoftwareSerial) | |
| D4 | ダンプボタン | `INPUT_PULLUP`。押下で LOW。デバウンス 50 ms |
| D10 | SD の CS | |
| D11 / D12 / D13 | SPI(MOSI / MISO / SCK) | **D13 は状態 LED と共用**。SD アクセス中は LED が点滅する |
| A0 | 故障 LED | 出力。直列抵抗を入れる。**旧 VIN 監視の分圧抵抗(33 kΩ/10 kΩ)が残っていれば外すこと** |
| A4 / A5 | I2C(SDA / SCL) | 外付けのプルアップ(目安 4.7 kΩ)を推奨 |

## 3. I2C デバイスとアドレス

### 3.1 24FC1025(外付け EEPROM)

24FC1025 は 128 KB(1 Mbit)で、コントロールバイトは `1 0 1 0 A2 A1 B0`(B0 = 64 KB ブロック選択)である(データシートの確認が必要)。
本設計は、3個を次のように結線する前提でアドレスを計算する。

| チップ | A2 | A1 | 7 bit アドレス | 担当する物理アドレス |
|---|---|---|---|---|
| chip0 | 0 | 0 | 0x50(ブロック0)/ 0x51(ブロック1) | 0 〜 131,071 |
| chip1 | 0 | 1 | 0x52 / 0x53 | 131,072 〜 262,143 |
| chip2 | 1 | 0 | 0x54 / 0x55 | 262,144 〜 393,215 |

アドレス計算(`mapAddress`):

```text
chip  = addr >> 17                 # 128 KB ごと
block = (addr >> 16) & 1           # 64 KB ごと
dev   = 0x50 | (chip << 1) | block
word  = addr & 0xFFFF              # 16 bit ワードアドレス
```

- 結線が異なると、起動時に `[WARN] EEPROM at 0x.. not responding` が出て、故障 LED が 3 回点滅する(05 章)。
- 32 B レコードは 32 B 境界に置くので、128 B ページ、64 KB ブロック、128 KB チップの境界をまたがない(07 章で検証)。

### 3.2 DS3231(RTC)

- アドレス 0x68。時刻は RTClib 経由で読む。**温度は、RTClib の float 版を使わず、レジスタ 0x11/0x12 を直接読んで整数化する**(Flash 節約。06 章)。
- CR2032 が切れると `lostPower()` が真になり、以降のレコードは「時刻不確か」フラグが付く(`SET` コマンドで時刻を設定するまで)。

## 4. 配線上の注意

- RS232 は ±12 V 級のレベルになりうる。必ず MAX3232(または同等品)を介すこと。Uno は 5 V 駆動のため、5 V 対応の MAX3232 モジュールを使う。
- SD モジュールは、5 V 入力に対応したレベル変換付きのものを使う。
- I2C は 3 個の EEPROM と RTC が同居し、クロックは 400 kHz にしている。プルアップとケーブル長に注意する(24FC1025 は 5 V で 400 kHz 以上に対応)。
- 24FC1025 のライトプロテクト(WP)ピンは GND に落とす。
- 電源の瞬断対策(ホールドアップ容量の追加)は、本設計の対象外だが、電源断耐性の観点では有効である(09 章 §3)。
