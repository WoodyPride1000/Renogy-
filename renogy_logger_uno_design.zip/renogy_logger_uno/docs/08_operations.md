# 08. 運用手順

## 1. ビルドと書き込み

1. `src/renogy_logger/` フォルダごと Arduino のスケッチフォルダに置く。**フォルダ名は `renogy_logger` のまま**にし、`renogy_logger.ino` と `renogy_logger.h` を同じフォルダに置く。
2. 必要なライブラリ: SdFat(2.x)、ModbusMaster、RTClib(2.x、Adafruit BusIO を含む)。`SoftwareSerial`、`SPI`、`Wire`、`EEPROM` は AVR コア付属。
3. ボードは「Arduino Uno」。書き込み後、シリアルモニタを 9600 bps で開く。
4. (任意)Flash/SRAM の節約フラグ。arduino-cli なら、次のように渡す。

```text
--build-property "compiler.cpp.extra_flags=-DUSE_LONG_FILE_NAMES=0 -DSERIAL_TX_BUFFER_SIZE=16 -DSERIAL_RX_BUFFER_SIZE=32 -D_SS_MAX_RX_BUFF=32"
```

   Arduino IDE 1.8.x なら、AVR コアのフォルダに `platform.local.txt` を作り、`compiler.cpp.extra_flags=<上と同じフラグ>` と書く(全スケッチに効く)。
5. (任意、`Stack free (min)` が 100 B 未満のとき)ModbusMaster の 2 箇所を編集する(06 章 §4)。

## 2. 初回の実機確認

1. 起動ログを確認する。
   - `[WARN] EEPROM at 0x.. not responding` が出なければ、24FC1025 の結線が想定どおり。
   - 空の EEPROM なら `Recovered Global Count: 0`。
2. 数分待つ。`[#n] BatV:.. PV:..W` が毎分出る。Renogy 未接続なら `NaN` になり、5 分後に故障 LED が 2 回点滅する(正常な挙動)。
3. `SET:YYYY,MM,DD,HH,MM,SS` で時刻を設定する(初回、または RTC の電池交換後)。
4. `DUMP`(またはボタン)で SD に出力し、`datalog.csv` を確認する。
5. `STATUS` で `Stack free (min)` を読む(判断は 06 章 §3.3)。
6. 電源を抜いて再投入し、`Recovered Global Count` が直前の続きから始まることを確認する。
7. Renogy を接続した状態で、1〜6 を再度行う。

## 3. シリアルコマンド(9600 bps、行末は LF または CRLF)

| コマンド | 動作 |
|---|---|
| `SET:YYYY,MM,DD,HH,MM,SS` | RTC を設定し、時刻不確かフラグを解除する。年は 2000〜2099、範囲外・余りがあれば拒否 |
| `TIME` | 現在の RTC 時刻を表示する(時刻不確かなら `[UNRELIABLE TIME]` を付ける) |
| `DUMP` | 未出力分を SD に出力する(ボタンと同じ)。復旧待ちのときは拒否 |
| `STATUS` | 状態(VALID / WAITING)、Global Count、Last Dumped、Pending、EEPROM 連続エラー数、Renogy 連続失敗数、`Fault flags`、`Stack free (min)` |
| `FORCE:<count>` | 復旧待ちのときだけ有効。指定した count から開始する(05 章 §4) |

行が 39 文字を超えると、その行は改行まで捨てる。

## 4. LED

| LED | 意味 |
|---|---|
| D13(状態) | 記録中・ダンプ中に点灯。SD アクセス中は SCK と共用のため点滅する。起動時に 3 回点滅 |
| A0(故障) | 点滅回数で原因を示す(05 章 §1)。1=EEPROM、2=Renogy、3=IC 応答なし、4=状態復元が不確か |

## 5. SD のデータ回収

1. ボタンを押す(または `DUMP`)。`Flushed N ok, M corrupt/empty.` と出るまで待つ。ダンプ中は**記録が止まる**(数十秒以上かかりうる)。
2. SD を抜く。ダンプ中に抜かないこと。
3. 次のダンプでは、前回の続き(`lastDumpedCount` 以降)から出力される。
4. 8.5 日以上ダンプしないと、古い側が上書きされて失われる(`GAP` 行で欠落が示される)。

## 6. CSV の解析(Python)

重複(再ダンプ)の除去、特別な行の除外、`NaN` の扱いを行う。

```python
import pandas as pd

df = pd.read_csv("datalog.csv", dtype=str)
df["count_num"] = pd.to_numeric(df["count"], errors="coerce")
df = df.dropna(subset=["count_num"])
df["count_num"] = df["count_num"].astype("int64")

# GAP / CORRUPT_OR_EMPTY 行を除外(datetime 列が日付ではない行)
valid = df[df["datetime"].str.match(r"^\d{4}-", na=False)].copy()

# 重複を除去(有効な行を優先)
valid = valid.sort_values("count_num").drop_duplicates("count_num", keep="first")

for c in ["batV", "batA", "soc", "pvW", "pvV", "pvA", "temp"]:
    valid[c] = pd.to_numeric(valid[c], errors="coerce")   # "NaN" は NaN になる
valid["datetime"] = pd.to_datetime(valid["datetime"], errors="coerce")
valid["time_unreliable"] = valid["flag"].eq("UNCERTAIN_TIME")
```

## 7. トラブルシュート

| 症状 | 確認 | 対処 |
|---|---|---|
| ビルドで `does not name a type` | `.ino` と `.h` が同じフォルダにあるか | 両方を `renogy_logger/` に置く |
| 起動時に `EEPROM at 0x.. not responding` | A1/A2 の結線(02 章 §3.1)、電源、プルアップ | 結線を直す。応答したアドレスから、どのチップかを特定する |
| `[WAIT] count unknown` | バスの死活(SDA/SCL の配線)、チップ | 配線を確認する。復旧しなければ `FORCE:<CSV の最大 count より大きい値>` |
| 故障 LED が 2 回点滅 | Renogy の接続、RS232 のレベル変換、ボーレート | 接続を確認する。センチネル(`NaN`)が記録されている |
| `Reset cause ... (WDT)` | どの処理で固着したか | `STATUS` と直前のログを保存する |
| ダンプで `SD mount FAILED` | カードの種類(FAT16/32)、配線、CS ピン | カードを再フォーマットする(FAT32) |
| 動作が不安定 | `Stack free (min)`、電源 | 06 章 §4 の対策を行う。電源を確認する |
