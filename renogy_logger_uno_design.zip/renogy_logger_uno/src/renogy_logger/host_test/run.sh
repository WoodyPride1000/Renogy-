#!/bin/bash
# 電源断注入テスト。スケッチ本体を、AVR 固有の属性3つを外しただけでホストにコンパイルして実行する。
#   bash run.sh        全件(約3分)    bash run.sh quick   短縮版(約30秒)
set -e
cd "$(dirname "$0")"
# .ino 内の #include "renogy_logger.h" を .h の中身で置き換え、AVR 固有の属性3つだけ外す(ロジックは無改変)
sed -e '/#include "renogy_logger.h"/{r ../renogy_logger.h' -e 'd}' ../renogy_logger.ino \
  | sed -e '/^#pragma once/d' \
        -e 's/__attribute__((naked))//' \
        -e 's/__attribute__((section("\.init3")))//' \
        -e 's/__attribute__((section("\.noinit")))//' > sketch_host.cpp
g++ -std=gnu++11 -O2 -Wall -Wno-unused-function -Wno-unused-variable -I. -o "${TMPDIR:-/tmp}/renogy_harness" harness.cpp
"${TMPDIR:-/tmp}/renogy_harness" "$@"
