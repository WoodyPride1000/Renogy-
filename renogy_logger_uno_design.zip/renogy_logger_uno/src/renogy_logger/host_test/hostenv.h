#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <string>
#include <vector>
#include <array>
#include <map>
#include <algorithm>

#define PSTR(s) (s)
#define _BV(b) (1 << (b))
#define HIGH 1
#define LOW 0
#define INPUT_PULLUP 2
#define OUTPUT 1
#define A0 14
#define A4 18
#define A5 19
#define DEC 10
#define HEX 16
#define BUFFER_LENGTH 32
#define O_WRITE 1
#define O_CREAT 2
#define O_APPEND 4
#define SD_SCK_MHZ(x) ((x) * 1000000UL)
#define WDRF 3
#define BORF 2
#define WDTO_8S 9
class __FlashStringHelper;
#define F(s) (reinterpret_cast<const __FlashStringHelper *>(s))

struct PowerCut {};

// ---- 偽ハードウェア状態 -------------------------------------------------
static uint8_t  g_ext[393216];            // 24FC1025 x3
static uint8_t  g_int[1024];              // ATmega328P 内蔵 EEPROM
static uint64_t g_events = 0;             // バイト書き込みイベント通し番号
static uint64_t g_cutAt = UINT64_MAX;     // このイベントで電源断
static bool     g_torn = false;           // true: 切れたバイトに不定値が残る
static uint64_t g_clockUs = 0;
static uint8_t  g_chipBusy[3] = {0, 0, 0};
static uint32_t g_ptr[3] = {0, 0, 0};
static uint32_t g_sample = 0;
static uint32_t g_now = 0;
static std::string g_sdPending, g_sdFile;  // close() まで確定しない
static std::vector<uint32_t> g_sdRows;
static uint32_t g_sdNext = 0;
static int g_sdCorrupt = 0;
static volatile uint8_t MCUSR = 0;
static bool g_modbusFail = false;
static uint8_t g_dsMsb = 25, g_dsLsb = 0, g_dsReg = 0;
static bool g_dsFail = false;

static inline void progByte(uint8_t *mem, uint32_t a, uint8_t v) {
  if (g_events++ == g_cutAt) {
    if (g_torn) mem[a] = (uint8_t)(v ^ 0xA5);   // 書き込み途中の不定値
    throw PowerCut();
  }
  mem[a] = v;
}

// ---- Arduino 基本 -------------------------------------------------------
static inline void pinMode(uint8_t, uint8_t) {}
static inline void digitalWrite(uint8_t, uint8_t) {}
static inline int digitalRead(uint8_t) { return HIGH; }
static inline void delay(unsigned long ms) { g_clockUs += ms * 1000UL; }
static inline void delayMicroseconds(unsigned int us) { g_clockUs += us; }
static inline unsigned long millis() { return (unsigned long)(g_clockUs / 1000); }
static inline void wdt_reset() {}
static inline void wdt_enable(int) {}
static inline void wdt_disable() {}

class Print {
public:
  virtual ~Print() {}
  virtual size_t write(uint8_t) = 0;
  size_t write(const char *s) { size_t n = 0; while (*s) { write((uint8_t)*s++); n++; } return n; }
  size_t print(const __FlashStringHelper *f) { return write((const char *)f); }
  size_t print(const char *s) { return write(s); }
  size_t print(char c) { return write((uint8_t)c); }
  size_t print(unsigned char v, int b = DEC) { return pu(v, b); }
  size_t print(int v, int b = DEC) { return pi(v, b); }
  size_t print(unsigned int v, int b = DEC) { return pu(v, b); }
  size_t print(long v, int b = DEC) { return pi(v, b); }
  size_t print(unsigned long v, int b = DEC) { return pu(v, b); }
  size_t print(double v, int d = 2) { char buf[40]; snprintf(buf, sizeof buf, "%.*f", d, v); return write((const char *)buf); }
  size_t println() { return write((uint8_t)'\n'); }
  size_t println(const __FlashStringHelper *f) { return print(f) + println(); }
  size_t println(const char *s) { return print(s) + println(); }
  size_t println(unsigned char v, int b = DEC) { return print(v, b) + println(); }
  size_t println(int v, int b = DEC) { return print(v, b) + println(); }
  size_t println(unsigned int v, int b = DEC) { return print(v, b) + println(); }
  size_t println(long v, int b = DEC) { return print(v, b) + println(); }
  size_t println(unsigned long v, int b = DEC) { return print(v, b) + println(); }
  size_t println(double v, int d = 2) { return print(v, d) + println(); }
private:
  size_t pu(unsigned long v, int b) { char buf[24]; snprintf(buf, sizeof buf, b == 16 ? "%lX" : "%lu", v); return write((const char *)buf); }
  size_t pi(long v, int b) { char buf[24]; if (b == 16) snprintf(buf, sizeof buf, "%lX", (unsigned long)v); else snprintf(buf, sizeof buf, "%ld", v); return write((const char *)buf); }
};
class Stream : public Print { public: virtual int available() = 0; virtual int read() = 0; };
class HardwareSerial : public Stream {
public:
  void begin(unsigned long) {}
  size_t write(uint8_t) { return 1; }
  int available() { return 0; }
  int read() { return -1; }
  void flush() {}
};
static HardwareSerial Serial;
class SoftwareSerial : public Stream {
public:
  SoftwareSerial(uint8_t, uint8_t) {}
  void begin(long) {}
  size_t write(uint8_t) { return 1; }
  int available() { return 0; }
  int read() { return -1; }
};

// ---- Wire: 24FC1025 x3 (128B ページ、書き込み中は NACK、ポインタ付きランダム読み) ----
struct TwoWire {
  uint8_t tx[BUFFER_LENGTH]; uint8_t txn = 0; uint8_t txAddr = 0;
  uint8_t rx[64]; uint8_t rxn = 0, rxi = 0;
  void begin() {} void end() {} void setClock(uint32_t) {}
  bool setWireTimeout(uint32_t = 0, bool = false) { return true; }
  void beginTransmission(uint8_t a) { txAddr = a; txn = 0; }
  size_t write(uint8_t b) { if (txn >= BUFFER_LENGTH) return 0; tx[txn++] = b; return 1; }   // 溢れたら黙って捨てる(実機同様)
  size_t write(const uint8_t *d, size_t n) { size_t w = 0; while (w < n && write(d[w])) w++; return w; }
  uint8_t endTransmission() {
    g_clockUs += 100;
    if (txAddr == 0x68) { if (g_dsFail) return 2; if (txn >= 1) g_dsReg = tx[0]; return 0; }   // DS3231
    if (txAddr < 0x50 || txAddr > 0x55) return 2;
    uint8_t idx = txAddr - 0x50, chip = idx >> 1, block = idx & 1;
    if (g_chipBusy[chip]) { g_chipBusy[chip]--; return 2; }
    if (txn == 0) return 0;
    if (txn < 2) return 4;
    uint32_t word = ((uint32_t)tx[0] << 8) | tx[1];
    uint32_t lin = chip * 131072UL + block * 65536UL + word;
    g_ptr[chip] = lin;
    if (txn == 2) return 0;
    uint32_t pageBase = lin & ~127UL;
    for (uint8_t i = 2; i < txn; i++) progByte(g_ext, pageBase + ((lin + (i - 2)) & 127UL), tx[i]);   // ページ内で折り返す
    g_chipBusy[chip] = 1;
    return 0;
  }
  uint8_t requestFrom(int addr, int n) {
    g_clockUs += 100; rxn = rxi = 0;
    if (addr == 0x68) {
      if (g_dsFail) return 0;
      for (int i = 0; i < n && i < 64; i++) rx[i] = (g_dsReg + i == 0x11) ? g_dsMsb : ((g_dsReg + i == 0x12) ? g_dsLsb : 0);
      rxn = n; return n;
    }
    if (addr < 0x50 || addr > 0x55) return 0;
    uint8_t chip = (addr - 0x50) >> 1;
    if (g_chipBusy[chip]) { g_chipBusy[chip]--; return 0; }
    if (n > 64) n = 64;
    for (int i = 0; i < n; i++) rx[i] = g_ext[(g_ptr[chip] + i) % 393216UL];
    g_ptr[chip] += n; rxn = n; return n;
  }
  int available() { return rxn - rxi; }
  int read() { return rxi < rxn ? rx[rxi++] : -1; }
};
static TwoWire Wire;

// ---- 内蔵 EEPROM (update 相当: 変化するバイトだけ書く) ----
struct EEPROMClass {
  template <typename T> T &get(int idx, T &t) { memcpy(&t, g_int + idx, sizeof(T)); return t; }
  template <typename T> const T &put(int idx, const T &t) {
    const uint8_t *p = (const uint8_t *)&t;
    for (size_t i = 0; i < sizeof(T); i++) if (g_int[idx + i] != p[i]) progByte(g_int, idx + i, p[i]);
    return t;
  }
};
static EEPROMClass EEPROM;

// ---- RTC / Modbus / SD ----
class DateTime {
public:
  DateTime() : y(2026), mo(1), d(1), h(0), mi(0), s(0) {}
  DateTime(uint16_t y_, uint8_t mo_, uint8_t d_, uint8_t h_, uint8_t mi_, uint8_t s_) : y(y_), mo(mo_), d(d_), h(h_), mi(mi_), s(s_) {}
  uint16_t year() const { return y; } uint8_t month() const { return mo; } uint8_t day() const { return d; }
  uint8_t hour() const { return h; } uint8_t minute() const { return mi; } uint8_t second() const { return s; }
private: uint16_t y; uint8_t mo, d, h, mi, s;
};
class RTC_DS3231 {
public:
  bool begin() { return true; } bool lostPower() { return false; } void adjust(const DateTime &) {}
  DateTime now() { return DateTime(2026, 11, 14, (g_now / 3600) % 24, (g_now / 60) % 60, g_now % 60); }
  float getTemperature() { return 20.0f + (g_sample % 50) * 0.25f; }
};
class ModbusMaster {
public:
  static const uint8_t ku8MBSuccess = 0;
  void begin(uint8_t, Stream &) {}
  uint8_t readHoldingRegisters(uint16_t, uint16_t) { return g_modbusFail ? 226 : 0; }
  uint16_t getResponseBuffer(uint8_t i) { return (uint16_t)((g_sample * 37u + i * 11u) % 1500u); }
};
class SdFile : public Print {
public:
  size_t write(uint8_t c) { g_sdPending.push_back((char)c); return 1; }
  bool open(const char *, int) { g_sdPending.clear(); return true; }
  uint32_t fileSize() { return (uint32_t)g_sdFile.size(); }
  bool sync() { return true; }
  bool getWriteError() { return false; }
  bool close() {                         // close() で初めて確定する(それ以前の電源断では消える)
    size_t pos = 0;
    while (pos < g_sdPending.size()) {
      size_t e = g_sdPending.find('\n', pos); if (e == std::string::npos) e = g_sdPending.size();
      std::string line = g_sdPending.substr(pos, e - pos); pos = e + 1;
      if (!line.empty() && isdigit((unsigned char)line[0])) {
        if (line.find(",GAP,") != std::string::npos) continue;
        if (line.find("CORRUPT") != std::string::npos) g_sdCorrupt++;
        uint32_t c = (uint32_t)strtoul(line.c_str(), 0, 10);
        g_sdRows.push_back(c); if (c + 1 > g_sdNext) g_sdNext = c + 1;
      }
    }
    g_sdFile += g_sdPending; g_sdPending.clear(); return true;
  }
};
class SdFat { public: bool begin(uint8_t, uint32_t) { return true; } };
