// 電源断注入ハーネス: スケッチ本体(sketch_host.cpp)を同一翻訳単位に取り込み、全バイト位置で電源を切る。
#include "hostenv.h"
#include "sketch_host.cpp"

static const uint32_t CAP = CAPACITY_RECORDS;
static uint16_t crcTab[256];
static void initCrc() {
  for (int i = 0; i < 256; i++) { uint16_t c = i; for (int j = 0; j < 8; j++) c = (c & 1) ? (c >> 1) ^ 0xA001 : c >> 1; crcTab[i] = c; }
}
static uint16_t crcFast(const uint8_t *p, size_t n) { uint16_t c = 0xFFFF; while (n--) c = (c >> 8) ^ crcTab[(c ^ *p++) & 0xFF]; return c; }

static std::string g_err;
#define CHECK(cond, ...) do { if (!(cond)) { char _b[300]; snprintf(_b, sizeof _b, __VA_ARGS__); g_err += _b; return false; } } while (0)

struct Snapshot {
  std::string name; std::vector<uint8_t> ext, in; uint32_t baseCount;
  std::string sdFile; std::vector<uint32_t> sdRows; uint32_t sdNext; int sdCorrupt;
};
struct Oracle { const std::vector<uint8_t> *base; uint32_t baseCount; std::map<uint32_t, std::array<uint8_t, 32>> ack; };

static void resetRam() {
  globalCount = 0; lastDumpedCount = 0; stateValid = false; consecutiveErrors = 0; renogyFailCount = 0;
  faultFlags = 0; metaSlot = 0; rtcPowerLostFlag = false;
  g_chipBusy[0] = g_chipBusy[1] = g_chipBusy[2] = 0; g_sdPending.clear();
}
static void rebootClean() { resetRam(); g_cutAt = UINT64_MAX; setup(); }   // 実機の setup() をそのまま通す

static void restore(const Snapshot &S) {
  memcpy(g_ext, S.ext.data(), sizeof g_ext); memcpy(g_int, S.in.data(), sizeof g_int);
  g_sdFile = S.sdFile; g_sdRows = S.sdRows; g_sdNext = S.sdNext; g_sdCorrupt = S.sdCorrupt; g_sdPending.clear();
}

static bool rawRead(uint32_t slot, LogRecord &r) {
  memcpy(&r, g_ext + (size_t)slot * 32, 32);
  return r.crc16 == crcFast((const uint8_t *)&r, 30);
}

static std::vector<uint32_t> s_cnt(CAP);
static std::vector<uint8_t> s_ok(CAP);

// 起動直後の不変条件
static bool verifyBoot(const Oracle &o) {
  CHECK(stateValid, "stateValid=false");
  uint32_t maxValid = 0; bool any = false;
  for (uint32_t s = 0; s < CAP; s++) {
    LogRecord r;
    if (rawRead(s, r)) {
      CHECK(r.count % CAP == s, "slot %u holds count %u", s, r.count);
      s_ok[s] = 1; s_cnt[s] = r.count;
      if (!any || r.count > maxValid) { maxValid = r.count; any = true; }
    } else s_ok[s] = 0;
  }
  uint32_t expectG = any ? maxValid + 1 : 0;
  CHECK(globalCount == expectG, "G=%u but expected %u (regression/duplicate/skip)", globalCount, expectG);
  uint32_t lo = (globalCount >= CAP) ? globalCount - CAP + 1 : 0;   // G-CAP のスロットは書き込み中で失ってよい
  for (uint32_t c = lo; c < globalCount; c++) {
    uint32_t s = c % CAP;
    CHECK(s_ok[s] && s_cnt[s] == c, "hole at count %u (G=%u)", c, globalCount);
    const uint8_t *cur = g_ext + (size_t)s * 32;
    if (c < o.baseCount) { CHECK(memcmp(cur, o.base->data() + (size_t)s * 32, 32) == 0, "base record %u changed", c); }
    else { auto it = o.ack.find(c); if (it != o.ack.end()) CHECK(memcmp(cur, it->second.data(), 32) == 0, "acked record %u changed", c); }
  }
  CHECK(lastDumpedCount <= globalCount, "lastDumped %u > G %u", lastDumpedCount, globalCount);
  CHECK(lastDumpedCount <= g_sdNext, "lastDumped %u > sdNext %u (未出力データを出力済みと誤認 = 欠落)", lastDumpedCount, g_sdNext);
  return true;
}

static bool checkSd() {
  { size_t pos = 0; while (pos < g_sdFile.size()) { size_t e = g_sdFile.find('\n', pos); if (e == std::string::npos) break;
      int commas = 0; for (size_t i = pos; i < e; i++) if (g_sdFile[i] == ',') commas++;
      CHECK(commas == 9, "CSV row has %d commas (expected 9)", commas); pos = e + 1; } }
  CHECK(g_sdCorrupt == 0, "CORRUPT_OR_EMPTY rows in SD: %d", g_sdCorrupt);
  std::vector<uint32_t> v = g_sdRows; std::sort(v.begin(), v.end()); v.erase(std::unique(v.begin(), v.end()), v.end());
  for (size_t i = 1; i < v.size(); i++) CHECK(v[i] == v[i - 1] + 1, "SD count gap %u -> %u", v[i - 1], v[i]);
  return true;
}

static bool logOne(Oracle &o) {
  uint32_t c = globalCount; g_sample = c; g_now = 1000000u + c * 60u;
  g_dsMsb = (uint8_t)((int)(c % 60) - 15); g_dsLsb = (uint8_t)((c % 4) << 6);
  g_modbusFail = (c % 7 == 3); g_dsFail = (c % 11 == 5);
  readRenogyData();                                // loop() と同じ順序
  logToEEPROM();                                   // 電源断なら PowerCut が飛ぶ
  CHECK(globalCount == c + 1, "G=%u after logging #%u", globalCount, c);
  LogRecord r; CHECK(rawRead(c % CAP, r) && r.count == c, "record #%u unreadable after ack", c);
  memcpy(o.ack[c].data(), &r, 32);
  return true;
}
static bool doFlush() {
  flushToSD();
  CHECK(lastDumpedCount == globalCount, "after flush lastDumped=%u G=%u", lastDumpedCount, globalCount);
  CHECK(g_sdNext == globalCount, "after flush sdNext=%u G=%u", g_sdNext, globalCount);
  return true;
}

static Snapshot build(const char *name, uint32_t count, int flushAt) {
  memset(g_ext, 0xFF, sizeof g_ext); memset(g_int, 0xFF, sizeof g_int);
  g_sdFile.clear(); g_sdRows.clear(); g_sdNext = 0; g_sdCorrupt = 0;
  Oracle o{nullptr, 0, {}}; rebootClean();
  for (uint32_t i = 0; i < count; i++) {
    if (!logOne(o)) { fprintf(stderr, "build failed: %s\n", g_err.c_str()); exit(2); }
    if ((int)(i + 1) == flushAt) { if (!doFlush()) { fprintf(stderr, "build flush failed: %s\n", g_err.c_str()); exit(2); } }
  }
  Snapshot S; S.name = name; S.ext.assign(g_ext, g_ext + sizeof g_ext); S.in.assign(g_int, g_int + sizeof g_int);
  S.baseCount = count; S.sdFile = g_sdFile; S.sdRows = g_sdRows; S.sdNext = g_sdNext; S.sdCorrupt = g_sdCorrupt;
  return S;
}

static bool postPhase(Oracle &o) {      // 電源断なしで続行 -> ダンプ -> 通常再起動 -> 再検証
  for (int k = 0; k < 6; k++) if (!logOne(o)) return false;
  if (!doFlush()) return false;
  if (!checkSd()) return false;
  rebootClean(); if (!verifyBoot(o)) return false;
  return checkSd();
}

// 1つの切断点(イベント番号, torn の有無)を検証
static bool runWindow(const Snapshot &S, uint64_t cutIdx, bool torn, int R, const std::vector<int> &flushAfter, bool &cutHappened, uint64_t *evOut) {
  g_err.clear(); cutHappened = false;
  restore(S); Oracle o{&S.ext, S.baseCount, {}};
  rebootClean(); if (!verifyBoot(o)) { g_err = "[initial] " + g_err; return false; }
  g_events = 0; g_cutAt = cutIdx; g_torn = torn;
  try {
    for (int i = 0; i < R; i++) {
      if (!logOne(o)) return false;
      for (int f : flushAfter) if (f == i + 1) { if (!doFlush()) return false; }
    }
  } catch (PowerCut &) { cutHappened = true; }
  if (evOut) *evOut = g_events;
  g_cutAt = UINT64_MAX;
  if (cutHappened) { rebootClean(); if (!verifyBoot(o)) { g_err = "[after cut] " + g_err; return false; } }
  if (!postPhase(o)) { g_err = "[post] " + g_err; return false; }
  return true;
}

// 乱数で複数回の電源断を重ねる
static bool fuzzOne(const std::vector<Snapshot> &snaps, const std::vector<int> &ids, uint32_t seed, std::string &desc) {
  uint32_t st = seed ? seed : 1; auto rnd = [&]() { st ^= st << 13; st ^= st >> 17; st ^= st << 5; return st; };
  const Snapshot &S = snaps[ids[rnd() % ids.size()]];
  g_err.clear(); restore(S); Oracle o{&S.ext, S.baseCount, {}};
  char b[120]; snprintf(b, sizeof b, "fuzz seed=%u snap=%s", seed, S.name.c_str()); desc = b;
  rebootClean(); if (!verifyBoot(o)) return false;
  int cuts = 1 + rnd() % 4;
  for (int c = 0; c < cuts; c++) {
    g_events = 0; g_cutAt = 1 + rnd() % 1200; g_torn = rnd() & 1;
    try {
      int n = 3 + rnd() % 30;
      for (int i = 0; i < n; i++) { if (!logOne(o)) return false; if (rnd() % 8 == 0) { if (!doFlush()) return false; } }
    } catch (PowerCut &) {}
    g_cutAt = UINT64_MAX;
    rebootClean(); if (!verifyBoot(o)) { g_err = "[fuzz reboot] " + g_err; return false; }
  }
  return postPhase(o);
}


#include <regex>
struct Cap : Print { std::string s; size_t write(uint8_t ch) { s.push_back((char)ch); return 1; } };
static bool formatTests() {
  // 1) printFixed: 全 int16 値 x dec=1,2 を厳密な十進表記と比較。旧 float 実装との差も数える。
  long oldMismatch = 0;
  for (int v = -32768; v <= 32767; v++) for (int dec = 1; dec <= 2; dec++) {
    Cap cp; printFixed(cp, v, dec);
    long a = labs(v), dv = dec == 1 ? 10 : 100; char ref[40];
    snprintf(ref, sizeof ref, "%s%ld.%0*ld", v < 0 ? "-" : "", a / dv, dec, a % dv);
    CHECK(cp.s == ref, "printFixed(%d,%d)='%s' ref='%s'", v, dec, cp.s.c_str(), ref);
    char old[40]; snprintf(old, sizeof old, "%.*f", dec, (double)(v * (dec == 1 ? 0.1f : 0.01f)));
    if (cp.s != old) oldMismatch++;
  }
  { Cap cp; printFixedOrNaN(cp, INVALID_I16, 2); CHECK(cp.s == "NaN", "NaN not printed"); }
  printf("  printFixed: 全 131072 通りが厳密一致 (旧float実装との相違 %ld 通り)\n", oldMismatch);
  // 2) パーサ
  { const char *ok = "2026,11,15,12,30,45"; int a, b, c, d, e, f; const char *q = ok;
    CHECK(parseField(q, a, ',') && parseField(q, b, ',') && parseField(q, c, ',') && parseField(q, d, ',') && parseField(q, e, ',') && parseField(q, f, 0) && a == 2026 && f == 45, "parseField valid"); }
  const char *bad[] = {"2026,11,15,12,30,45x", "2026,11,15,12,30,", "2026,,15,12,30,45", "-1,11,15,12,30,45", "2026,11,15,12,30", "99999,1,1,1,1,1", ""};
  for (const char *b : bad) { int a, bb, c, d, e, f; const char *q = b;
    bool r = parseField(q, a, ',') && parseField(q, bb, ',') && parseField(q, c, ',') && parseField(q, d, ',') && parseField(q, e, ',') && parseField(q, f, 0);
    CHECK(!r, "parseField accepted bad '%s'", b); }
  { uint32_t v = 0; CHECK(parseU32("4294967295", v) && v == 4294967295u, "u32 max"); CHECK(!parseU32("4294967296", v), "u32 overflow accepted");
    CHECK(!parseU32("12a", v) && !parseU32("", v) && !parseU32("-1", v), "u32 bad accepted"); CHECK(parseU32("0", v) && v == 0, "u32 zero"); }
  // 3) コマンド
  resetRam(); rtcPowerLostFlag = true; char b1[] = "SET:2026,13,15,12,30,45"; handleCommand(b1); CHECK(rtcPowerLostFlag, "invalid SET accepted");
  char b2[] = "SET:2026,11,15,12,30,45"; handleCommand(b2); CHECK(!rtcPowerLostFlag, "valid SET rejected");
  stateValid = false; char b3[] = "FORCE:4294967296"; handleCommand(b3); CHECK(!stateValid, "FORCE overflow accepted");
  char b4[] = "FORCE:12a"; handleCommand(b4); CHECK(!stateValid, "FORCE garbage accepted");
  char b5[] = "FORCE:4000000000"; handleCommand(b5); CHECK(stateValid && globalCount == 4000000000u, "FORCE valid failed");
  // 4) DS3231 温度: 全レジスタ値 (msb 256 x frac 4) を trunc(温度*10) と比較
  g_dsFail = false;
  for (int m = 0; m < 256; m++) for (int fr = 0; fr < 4; fr++) {
    g_dsMsb = (uint8_t)m; g_dsLsb = (uint8_t)(fr << 6);
    double t = (int8_t)m + fr * 0.25; int expect = (int)(t * 10.0);   // 0 方向への丸め
    int got = readTempTenths(); CHECK(got == expect, "temp msb=%d fr=%d got=%d expect=%d", m, fr, got, expect);
  }
  g_dsFail = true; CHECK(readTempTenths() == INVALID_I16, "DS3231 failure not reported"); g_dsFail = false;
  printf("  readTempTenths: 全 1024 通りが一致 / 失敗時は NaN\n");
  // 5) 実際の CSV 行(NaN・負温度を含む)を書式と値で検証
  Snapshot z = build("blank", 0, -1); restore(z); Oracle o{&z.ext, 0, {}}; rebootClean();
  for (int i = 0; i < 80; i++) if (!logOne(o)) return false;
  flushToSD(); CHECK(g_sdNext == 80, "flush rows");
  std::regex row("^(\\d+),(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}),(-?\\d+\\.\\d{2}|NaN),(-?\\d+\\.\\d{2}|NaN),(\\d+|NaN),(\\d+|NaN),(-?\\d+\\.\\d{2}|NaN),(-?\\d+\\.\\d{2}|NaN),(-?\\d+\\.\\d|NaN),(OK|UNCERTAIN_TIME)$");
  size_t pos = 0; int rows = 0, nanBat = 0, nanTemp = 0, negTemp = 0;
  while (pos < g_sdFile.size()) {
    size_t e = g_sdFile.find('\n', pos); std::string line = g_sdFile.substr(pos, e - pos); pos = e + 1;
    if (line.compare(0, 5, "count") == 0) continue;
    std::smatch m; CHECK(std::regex_match(line, m, row), "bad CSV row: %s", line.c_str());
    int seq = atoi(m[1].str().c_str());
    if (seq % 7 != 3) { char want[24]; int raw = (int)((seq * 37u + 1 * 11u) % 1500u) * 10; snprintf(want, sizeof want, "%d.%02d", raw / 100, raw % 100);
      CHECK(m[3].str() == want, "batV row %d got %s want %s", seq, m[3].str().c_str(), want); } else nanBat += (m[3].str() == "NaN");
    if (m[9].str() == "NaN") nanTemp++; else if (m[9].str()[0] == '-') negTemp++;
    rows++;
  }
  CHECK(rows == 80 && nanBat > 0 && nanTemp > 0 && negTemp > 0, "row coverage rows=%d nanBat=%d nanTemp=%d negTemp=%d", rows, nanBat, nanTemp, negTemp);
  printf("  CSV: 80 行すべて書式一致 (batV の値も検証。NaN=%d行, 温度NaN=%d行, 負温度=%d行 を含む)\n", nanBat, nanTemp, negTemp);
  return true;
}

int main(int argc, char **argv) {
  bool quick = argc > 1 && !strcmp(argv[1], "quick");
  initCrc();
  { uint8_t d[30]; for (int t = 0; t < 50; t++) { for (int i = 0; i < 30; i++) d[i] = rand(); if (crcFast(d, 30) != calculateCRC16(d, 30)) { puts("CRC mismatch"); return 2; } }
    uint8_t blank[30]; memset(blank, 0xFF, 30); printf("blank slot CRC valid? %s\n", crcFast(blank, 30) == 0xFFFF ? "YES (危険)" : "no"); }
  printf("sizeof(LogRecord)=%u capacity=%u\n", (unsigned)sizeof(LogRecord), CAP);

  g_err.clear(); if (!formatTests()) { printf("FAIL formatTests: %s\n", g_err.c_str()); return 1; }
  const int R = quick ? 12 : 24;
  std::vector<Snapshot> snaps; std::vector<int> stride;
  snaps.push_back(build("blank(count=0)", 0, -1));                  stride.push_back(1);
  snaps.push_back(build("count=1003,flushed@1000", 1003, 1000));    stride.push_back(1);
  snaps.push_back(build("64KB block edge 2040", 2040, 2000));       stride.push_back(1);
  snaps.push_back(build("chip edge 4090", 4090, 4080));             stride.push_back(1);
  snaps.push_back(build("chip edge 8185", 8185, 8180));             stride.push_back(1);
  snaps.push_back(build("ring wrap CAP-20", CAP - 20, CAP - 30));   stride.push_back(1);
  snaps.push_back(build("2nd wrap 2*CAP-12", 2 * CAP - 12, 2 * CAP - 40)); stride.push_back(1);
  snaps.push_back(build("GAP path CAP+30 (no prior dump)", CAP + 30, -1)); stride.push_back(13);

  std::vector<int> fl = {R / 2, R - 2};
  long total = 0, fails = 0, cutsDone = 0; int shown = 0;
  for (size_t si = 0; si < snaps.size(); si++) {
    uint64_t E = 0; bool cut;
    if (!runWindow(snaps[si], UINT64_MAX, false, R, fl, cut, &E)) { printf("FAIL baseline %s: %s\n", snaps[si].name.c_str(), g_err.c_str()); fails++; continue; }
    long f0 = fails, n0 = total;
    for (uint64_t k = 0; k < E; k += stride[si]) for (int torn = 0; torn < 2; torn++) {
      total++;
      if (!runWindow(snaps[si], k, torn, R, fl, cut, nullptr)) {
        fails++; if (shown++ < 8) printf("FAIL [%s] cut@event %llu torn=%d : %s\n", snaps[si].name.c_str(), (unsigned long long)k, torn, g_err.c_str());
      } else if (cut) cutsDone++;
    }
    printf("%-34s events=%llu runs=%ld fails=%ld\n", snaps[si].name.c_str(), (unsigned long long)E, total - n0, fails - f0); fflush(stdout);
  }
  std::vector<int> ids; for (size_t i = 0; i + 1 < snaps.size(); i++) ids.push_back((int)i);
  int nf = quick ? 200 : 1500; long ffails = 0;
  for (int i = 1; i <= nf; i++) {
    std::string d;
    if (!fuzzOne(snaps, ids, 0x9E3779B1u * i + 12345, d)) { ffails++; fails++; if (shown++ < 8) printf("FAIL %s : %s\n", d.c_str(), g_err.c_str()); }
  }
  printf("fuzz(multi-cut) runs=%d fails=%ld\n", nf, ffails);
  printf("TOTAL exhaustive runs=%ld (cuts actually fired=%ld) + fuzz=%d, FAILS=%ld\n", total, cutsDone, nf, fails);
  return fails ? 1 : 0;
}
